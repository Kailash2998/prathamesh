from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator,MinValueValidator

'''
The STATE_CHOICES variable contains choices for the "state" field in models where it is used.
'''
STATE_CHOICES =(
    ('Bihar','Bihar'),
    ('Chhattisgarh','Chhattisgarh'),
    ('Maharashtra','Maharashtra'),
)


'''
This class represents a Customer model with various fields to store customer information.

user: ForeignKey linking to the User model.
name: Name of the customer.
locality: Locality of the customer.
city: City of the customer.
zipcode: Zip code of the customer. (Optional field)
state: State of the customer, chosen from predefined choices.
The __str__ method returns the ID of the customer in string format.
'''
class Customer(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    
    name = models.CharField(max_length=200)
    locality = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    zipcode = models.CharField(max_length=10, blank=True, null=True)
    state = models.CharField(choices=STATE_CHOICES,max_length=50)
    
    def __str__(self) -> str:
        return str(self.id)

'''
The CATEGORY_CHOICES variable contains choices for the "category" field in models where it is used.
'''
CATEGORY_CHOICES =(
    ('M','Mobile'),
    ('L','Laptop'),
    ('TW','Top Wear'),
    ('BW','Bottom Wear'),
    ('SW','Sport Wear'),
    ('PW','Party Wear'),
    ('Kurta','Kurta'),
)


'''
This class represents a Product model with various fields to store product information.

title:Title of the product
selling_price:Selling price of the product
discounted_price:Discounted price of the product
description: Description of the product
brand:Brand of the product
category:Category of the product
product_image:Image field to store the product image
The __str__ method returns the ID of the product in string format.
'''
class Product(models.Model):
    title = models.CharField(max_length=100)
    selling_price = models.FloatField()
    discounted_price = models.FloatField()
    description = models.TextField()
    brand = models.CharField(max_length=100)
    category = models.CharField(choices=CATEGORY_CHOICES, max_length=10)
    product_image = models.ImageField(upload_to='productimg')

    def __str__(self) -> str:
        return str(self.id)
    
    
'''
This class represents a Cart model for storing user's cart items.

user: ForeignKey linking to the User model.
product: ForeignKey linking to the Product model.
quantity: PositiveIntegerField representing the quantity of the product in the cart, defaulting to 1.
The __str__ method returns the ID of the cart item in string format.

The total_cost property calculates and returns the total cost .
'''
class Cart(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    
    def __str__(self) -> str:
        return str(self.id)
    
    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price


'''
The STATUS_CHOICES variable contains choices for the "status" field in models where it is used.
'''
STATUS_CHOICES =(
    ('Accepted','Accepted'),
    ('Pacekd','Pacekd'),
    ('On The Way','On The Way'),
    ('Delivered','Delivered'),
    ('Cancel','Cancel'),
)


'''
This class represents an OrderPlaced model for storing placed orders.
user: ForeignKey linking to the User model.
product: ForeignKey linking to the Product model.
quantity: PositiveIntegerField representing the quantity of the product ordered, defaulting to 1.
ordered_date: DateTimeField representing the date and time when the order was placed.
status: CharField representing the status of the order.
The total_cost property calculates and returns the total cost of the order.
'''
class OrderPlaced(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50,choices=STATUS_CHOICES,default='Pending')
   
    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price


