from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField,PasswordChangeForm
from django.contrib.auth.forms import PasswordResetForm,SetPasswordForm
from django.contrib.auth.models import User
from .models import Customer

'''
This is a Django form class for customer registration.
It extends the UserCreationForm, which is a built-in form for user registration with username and password.
'''
# class CustomerRegistrationForm(UserCreationForm):
#     password1 = forms.CharField(label='password',widget=forms.PasswordInput(attrs={'class' :'form-control'}))
#     password2 = forms.CharField(label='confirm password',widget=forms.PasswordInput(attrs={'class' :'form-control'}))
#     email = forms.CharField(required='True' ,widget=forms.EmailInput(attrs={'class' :'form-control'}))
#     class Meta:
#         model = User
#         fields = ['username','email','password1','password2']
#         labels = {'email':'Email'}
#         widgets = {'username':forms.TextInput(attrs={'class':'form-control'})}

class CustomerRegistrationForm(UserCreationForm):
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    role = forms.ChoiceField(label='Role', choices=(('seller', 'Seller'), ('customer', 'Customer')), widget=forms.Select(attrs={'class': 'form-control'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'role']
        labels = {'email': 'Email'}
        widgets = {'username': forms.TextInput(attrs={'class': 'form-control'})}

'''
This is a Django form class for user login.
It extends the AuthenticationForm, which is a built-in form for user authentication.
'''
class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={'autofocus': True, 'class': 'form-control'}))
    password = forms.CharField(label=("Password"), strip=False, widget=forms.PasswordInput(attrs={'autocomplete': 'current-password', 'autofocus': True, 'class': 'form-control'}))
    
    
'''
This is a Django form class for changing customer passwords.
It extends the PasswordChangeForm, which is a built-in form for changing user passwords.
'''
class CustomerPasswordChange(PasswordChangeForm):
    old_password = forms.CharField(label=("old password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))
    new_password1 = forms.CharField(label=("new password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))
    new_password2 = forms.CharField(label=("confirm new password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))


'''
This is a Django form class for resetting passwords.
It extends the PasswordResetForm, which is a built-in form for resetting user passwords.
'''
class PasswordResetForm(PasswordResetForm):
    email = forms.EmailField(label=("Email"),max_length=254,
                             widget=forms.EmailInput(attrs={'autocomplete':'email','class':'form-control'}))


'''
This is a Django form class for confirming the password reset.
It extends the SetPasswordForm, which is a built-in form for setting a new user password after a password reset request.
'''
class PasswordResetConfirmForm(SetPasswordForm):
     new_password1 = forms.CharField(label=("new password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))
     new_password2 = forms.CharField(label=("confirm new password"),strip=False,widget=forms.PasswordInput
    (attrs={'autocomplete':'currrent password' ,'autofocus':True,'class':'form-control' }))


'''
This is a Django ModelForm class for updating customer profiles.
It is associated with the Customer model.
'''
class CutomerProfileForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['id','name','locality','city','state','zipcode']
        widgets = {'name':forms.TextInput(attrs={'class':'form-control'}),
                   'locality':forms.TextInput(attrs={'class':'form-control'}),
                   'city':forms.TextInput(attrs={'class':'form-control'}),
                   'state':forms.Select(attrs={'class':'form-control'}),
                   'zipcode':forms.NumberInput(attrs={'class':'form-control'})}
    
